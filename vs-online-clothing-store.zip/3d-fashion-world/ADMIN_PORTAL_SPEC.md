# ADMIN PORTAL SPEC

The production admin portal should contain:

Dashboard
- revenue
- orders
- products
- inventory
- top collections

Products
- create/edit/delete product
- name, description, city/collection
- price and sale price
- sizes/colors
- stock quantity
- photos
- 3D GLB model
- featured flag

Orders
- customer details
- payment status
- fulfillment status
- tracking number

Collections / Locations
- add a city/location
- collection description
- hero media
- products assigned to location

Users
- customer list
- order history

Important: admin routes must be protected by authentication and server-side authorization. Never expose admin credentials in frontend JavaScript.
