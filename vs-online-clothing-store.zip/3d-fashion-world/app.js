const cities={
 Tokyo:{desc:"Future-forward silhouettes inspired by Tokyo after dark.",names:["Neo Signal Tee","Afterdark Hoodie","Orbit Shell Jacket"]},
 Paris:{desc:"Clean silhouettes with a quiet luxury attitude.",names:["Noir Atelier Tee","Ligne Hoodie","Paris Form Jacket"]},
 Mumbai:{desc:"Street energy, Indian culture and modern utility.",names:["Mumbai Night Tee","Monsoon Hoodie","Metro Utility Jacket"]},
 Hyderabad:{desc:"Traditional influence reimagined through a modern lens.",names:["Deccan Heritage Tee","Pearl City Hoodie","Charminar Overshirt"]}
};
const prices=[2499,4999,7499];
let cartItems=[];
const productsEl=document.getElementById("products");
function renderProducts(city){
 document.getElementById("cityTitle").textContent=city.toUpperCase();
 document.getElementById("cityDescription").textContent=cities[city].desc;
 productsEl.innerHTML=cities[city].names.map((name,i)=>`<button class="product" data-i="${i}"><div class="art"><div class="shirt"></div></div><div class="product-info"><p>${city.toUpperCase()} / 2026</p><h3>${name}</h3><p>₹${prices[i].toLocaleString("en-IN")}</p></div></button>`).join("");
 document.querySelectorAll(".product").forEach((p)=>p.onclick=()=>openProduct(city,Number(p.dataset.i)));
}
function openProduct(city,i){
 document.getElementById("modalCity").textContent=city.toUpperCase()+" COLLECTION";
 document.getElementById("modalName").textContent=cities[city].names[i];
 document.getElementById("modalDesc").textContent=cities[city].desc+" Premium everyday construction with a destination-inspired design.";
 document.getElementById("modalPrice").textContent="₹"+prices[i].toLocaleString("en-IN");
 document.getElementById("modalArt").innerHTML='<div class="shirt"></div>';
 document.getElementById("addBtn").onclick=()=>{cartItems.push({name:cities[city].names[i],price:prices[i]});updateCart();closeProduct()};
 document.getElementById("productModal").classList.add("open");
}
function closeProduct(){document.getElementById("productModal").classList.remove("open")}
function updateCart(){
 document.getElementById("bagCount").textContent=cartItems.length;
 document.getElementById("cartItems").innerHTML=cartItems.length?cartItems.map((x,i)=>`<div class="cart-item"><span>${x.name}</span><strong>₹${x.price.toLocaleString("en-IN")}</strong></div>`).join(""):"<p style='color:#777'>Your bag is empty.</p>";
 document.getElementById("total").textContent="₹"+cartItems.reduce((a,x)=>a+x.price,0).toLocaleString("en-IN");
}
document.querySelectorAll(".location").forEach(btn=>btn.onclick=()=>{document.querySelectorAll(".location").forEach(x=>x.classList.remove("active"));btn.classList.add("active");renderProducts(btn.dataset.city);document.getElementById("collection").scrollIntoView({behavior:"smooth"})});
document.getElementById("enterBtn").onclick=()=>document.getElementById("world").scrollIntoView({behavior:"smooth"});
document.getElementById("closeModal").onclick=closeProduct;
document.getElementById("bagBtn").onclick=()=>{document.getElementById("cart").classList.add("open");document.getElementById("overlay").style.display="block"};
document.getElementById("closeCart").onclick=()=>{document.getElementById("cart").classList.remove("open");document.getElementById("overlay").style.display="none"};
document.getElementById("overlay").onclick=()=>document.getElementById("closeCart").click();
renderProducts("Tokyo");

// Lightweight Three.js starfield
const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(75,innerWidth/innerHeight,.1,1000),renderer=new THREE.WebGLRenderer({canvas:document.getElementById("space"),alpha:true,antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(innerWidth,innerHeight);camera.position.z=2;
const geo=new THREE.BufferGeometry(),pts=5000,arr=new Float32Array(pts*3);
for(let i=0;i<pts*3;i++)arr[i]=(Math.random()-.5)*12;
geo.setAttribute("position",new THREE.BufferAttribute(arr,3));
const stars=new THREE.Points(geo,new THREE.PointsMaterial({color:0xffffff,size:.012,transparent:true,opacity:.8}));
scene.add(stars);
function animate(){requestAnimationFrame(animate);stars.rotation.y+=.00025;stars.rotation.x+=.00008;renderer.render(scene,camera)}
animate();
addEventListener("resize",()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
addEventListener("scroll",()=>{const y=scrollY;document.getElementById("earth").style.transform=`translateY(${Math.min(y*.12,180)}px) scale(${1+Math.min(y/5000,.25)})`;stars.rotation.z=y*.00015});
