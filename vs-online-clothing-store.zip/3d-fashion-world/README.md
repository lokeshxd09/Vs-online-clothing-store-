# VS — Online Clothing Store

A phone-friendly prototype for VS Online Clothing Store, using the crowned 8-ball identity and a cinematic space-to-world shopping journey.

## Included
- Space/starfield opening
- Earth-inspired visual
- Scroll-based storytelling sections
- Interactive fashion destinations
- Tokyo, Paris, Mumbai and Hyderabad collections
- Product viewer modal
- Size selection UI
- Shopping bag
- Responsive mobile layout

## Run
Open `index.html` in a browser, or deploy the folder to Vercel/Netlify/GitHub Pages.

## Next production phase
Connect a real database/auth/payment system (for example Supabase + a payment provider), replace placeholder product art with real 3D GLB models, and build the protected admin dashboard.

## Suggested production stack
Next.js + React + Three.js/React Three Fiber + GSAP + Supabase + payment provider.
